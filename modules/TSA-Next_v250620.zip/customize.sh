#!/system/bin/bash

SKIPUNZIP=1
SUPPORTED_ABIS="arm64 x64"
MIN_SDK=29

DEBUG=false
ui_print "- 安装模块"
ui_print "- TS-Assistant-Next#酷安:XtrLumen"
ui_print "- 开启篡改校验"
sleep 0.5
unzip -o "$ZIPFILE" 'verify.sh' -d "$TMPDIR" >/dev/null
if [ ! -f "$TMPDIR/verify.sh" ]; then
  ui_print "*********************************************************"
  ui_print "! 无法提取 verify.sh!"
  ui_print "! 这个ZIP文件已损坏,请重新下载"
  abort    "*********************************************************"
fi
. "$TMPDIR/verify.sh"
extract "$ZIPFILE" 'customize.sh' "$TMPDIR/.vunzip"
extract "$ZIPFILE" 'verify.sh' "$TMPDIR/.vunzip"

if [ "$API" -lt $MIN_SDK ]; then
  ui_print "! 安卓版本过低 $API"
  abort "! 最低支持的安卓版本 $MIN_SDK"
fi

ui_print "- 释放模块文件"
extract "$ZIPFILE" 'module.prop' "$MODPATH"
extract "$ZIPFILE" 'uninstall.sh' "$MODPATH"
extract "$ZIPFILE" 'cleanup.sh' "$MODPATH"
extract "$ZIPFILE" 'service.sh' "$MODPATH"
extract "$ZIPFILE" 'action.sh' "$MODPATH"

CONFIG_DIR=/data/adb/tricky_store
ui_print "- 创建配置目录"
mkdir -p "$CONFIG_DIR"
  extract "$ZIPFILE" 'target.txt' "$CONFIG_DIR"
ui_print "- 释放密钥文件"
  extract "$ZIPFILE" 'keybox.xml' "$CONFIG_DIR"
ui_print "- 释放哈希文件"
  extract "$ZIPFILE" 'hash.txt' "$CONFIG_DIR"

ui_print "- 安装模块"
ui_print "- TrickyStore_v1.3.0#Github:5ec1cff"
mkdir -p "/data/local/tmp/mod"
unzip -o "$ZIPFILE" "ts1.3.0.zip" -d "/data/local/tmp/mod" >&2
for ZIPFILE in "/data/local/tmp/mod"/*.zip; do
  install_module
done
ui_print "- 清除临时文件"
rm -rf "/data/local/tmp/mod/"
rm -rf "/data/adb/service.d/"
sleep 0.5

ui_print "- 读取包名添加"
pm list packages -3 | sed 's/package://g' > "$CONFIG_DIR/target.txt"
  sed -i '/me.bmax.apatch/d' "$CONFIG_DIR/target.txt"
  sed -i '/com.android.patch/d' "$CONFIG_DIR/target.txt"
  sed -i '$ a\com.google.android.gms' "$CONFIG_DIR/target.txt"
  sed -i '$ a\com.android.vending' "$CONFIG_DIR/target.txt"
sleep 0.5

ui_print "- 检测冲突模块"
DETECTED=0
if [ -d "/data/adb/modules/safetynet-fix" ]; then
  sed -i '6s/.*/description=此模块与TrickyStoreAssistant模块证实冲突，已被添加移除标签，将在下一次启动时被移除。/' "/data/adb/modules/safetynet-fix/module.prop"
  touch "/data/adb/modules/safetynet-fix/remove"
  if [ $? -eq 0 ]; then
    DETECTED=$((DETECTED + 1))
  fi
fi
if [ -d "/data/adb/modules/Tricky_store-bm" ]; then
  sed -i '6s/.*/description=此模块与TrickyStoreAssistant模块证实冲突，已被添加移除标签，将在下一次启动时被移除。/' "/data/adb/modules/Tricky_store-bm/module.prop"
  touch "/data/adb/modules/Tricky_store-bm/remove"
  if [ $? -eq 0 ]; then
    DETECTED=$((DETECTED + 1))
  fi
fi
if [ -d "/data/adb/modules/Tricky_Store-xiaoyi" ]; then
  sed -i '6s/.*/description=此模块与TrickyStoreAssistant模块证实冲突，已被添加移除标签，将在下一次启动时被移除。/' "/data/adb/modules/Tricky_Store-xiaoyi/module.prop"
  touch "/data/adb/modules/Tricky_Store-xiaoyi/remove"
  if [ $? -eq 0 ]; then
    DETECTED=$((DETECTED + 1))
  fi
fi
if [ -d "/data/adb/modules/TA_utl" ]; then
  touch "/data/adb/modules/TA_utl/remove"
  if [ $? -eq 0 ]; then
    DETECTED=$((DETECTED + 1))
  fi
fi
if [ $DETECTED -gt 0 ]; then
  ui_print "- 检测到$DETECTED个冲突模块，已添加移除标签与简介移除提示"
  ui_print "- 安装完毕"
else
  ui_print "- 未发现冲突"
  ui_print "- 安装完毕"
fi

exit 0