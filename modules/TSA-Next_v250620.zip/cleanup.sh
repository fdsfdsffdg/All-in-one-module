#!/system/bin/bash

if [ -f /data/adb/modules/tricky_store_assistant/disable ]; then
  sed -i '6s/.*/description=运行状态:[❌异常]模块被关闭!/' "/data/adb/modules/tricky_store_assistant/module.prop"
  rm -rf /data/adb/service.d/.tsa_cleanup.sh
fi