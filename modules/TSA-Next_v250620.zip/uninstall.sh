rm -rf /data/adb/tricky_store
rm -rf /data/adb/.tricky_store