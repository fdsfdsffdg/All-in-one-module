#!/system/bin/bash

check_reset_prop() {
  local NAME=$1
  local EXPECTED=$2
  local VALUE=$(resetprop $NAME)
  [ -z $VALUE ] || [ $VALUE = $EXPECTED ] || resetprop -n $NAME $EXPECTED
}
check_reset_prop "ro.secureboot.lockstate" "locked"
check_reset_prop "ro.boot.realmebootstate" "green"
check_reset_prop "ro.boot.realme.lockstate" "1"

contains_reset_prop() {
  local NAME=$1
  local CONTAINS=$2
  local NEWVAL=$3
  [[ "$(resetprop $NAME)" = *"$CONTAINS"* ]] && resetprop -n $NAME $NEWVAL
}
contains_reset_prop "ro.bootmode" "recovery" "unknown"
contains_reset_prop "ro.boot.bootmode" "recovery" "unknown"
contains_reset_prop "vendor.boot.bootmode" "recovery" "unknown"

resetprop ro.boot.vbmeta.device_state locked
resetprop ro.boot.verifiedbootstate green
resetprop ro.boot.flash.locked 1
resetprop ro.boot.veritymode enforcing
resetprop ro.boot.warranty_bit 0
resetprop ro.warranty_bit 0
resetprop ro.debuggable 0
resetprop ro.force.debuggable 0
resetprop ro.secure 1
resetprop ro.adb.secure 1
resetprop ro.build.type user
resetprop ro.build.tags release-keys
resetprop ro.vendor.boot.warranty_bit 0
resetprop ro.vendor.warranty_bit 0
resetprop vendor.boot.vbmeta.device_state locked
resetprop vendor.boot.verifiedbootstate green
resetprop sys.oem_unlock_allowed 0

if [ -s "/data/adb/tricky_store/hash.txt" ]; then
    hash=$(head -n1 "/data/adb/tricky_store/hash.txt")
    resetprop -n ro.boot.vbmeta.digest "$hash"
fi

until [ $(getprop sys.boot_completed) -eq 1 ] ; do
  sleep 1
done

sed -i '6s/.*/description=运行状态:[😋正常]服务运行中!/' "/data/adb/modules/tricky_store_assistant/module.prop"
rm -rf "/data/adb/modules/tricky_store_assistant/customize.sh"

if [ ! -f /data/adb/service.d/.tsa_cleanup.sh ]; then
  mkdir -p /data/adb/service.d/
  cat "/data/adb/modules/tricky_store_assistant/cleanup.sh" > /data/adb/service.d/.tsa_cleanup.sh
  chmod +x /data/adb/service.d/.tsa_cleanup.sh
fi

if [ -d "/data/adb/modules/safetynet-fix" ]; then
  sed -i '6s/.*/description=此模块与TrickyStoreAssistant模块证实冲突，已被添加移除标签，将在下一次启动时被移除。/' "/data/adb/modules/safetynet-fix/module.prop"
  touch "/data/adb/modules/safetynet-fix/remove"
fi
if [ -d "/data/adb/modules/Tricky_store-bm" ]; then
  sed -i '6s/.*/description=此模块与TrickyStoreAssistant模块证实冲突，已被添加移除标签，将在下一次启动时被移除。/' "/data/adb/modules/Tricky_store-bm/module.prop"
  touch "/data/adb/modules/Tricky_store-bm/remove"
fi
if [ -d "/data/adb/modules/Tricky_Store-xiaoyi" ]; then
  sed -i '6s/.*/description=此模块与TrickyStoreAssistant模块证实冲突，已被添加移除标签，将在下一次启动时被移除。/' "/data/adb/modules/Tricky_Store-xiaoyi/module.prop"
  touch "/data/adb/modules/Tricky_Store-xiaoyi/remove"
fi
if [ -d "/data/adb/modules/TA_utl" ]; then
  touch "/data/adb/modules/TA_utl/remove"
fi

[ -f /data/adb/apd ] && exit 0

pm list packages -3 | sed 's/package://g' > /data/adb/tricky_store/target.txt
  sed -i '/me.bmax.apatch/d' /data/adb/tricky_store/target.txt
  sed -i '/com.android.patch/d' /data/adb/tricky_store/target.txt
  sed -i '$ a\com.google.android.gms' /data/adb/tricky_store/target.txt
  sed -i '$ a\com.android.vending' /data/adb/tricky_store/target.txt

Last=""

while :; do
  This="$(stat -c %Y /data/system/packages.xml 2>/dev/null)"
  [ "$This" != "$Last" ] && {
    pm list packages -3 | sed 's/package://g' > /data/adb/tricky_store/target.txt
    sed -i '/me.bmax.apatch/d' /data/adb/tricky_store/target.txt
    sed -i '/com.android.patch/d' /data/adb/tricky_store/target.txt
    sed -i '$ a\com.google.android.gms' /data/adb/tricky_store/target.txt
    sed -i '$ a\com.android.vending' /data/adb/tricky_store/target.txt
    Last="$This"
  }
  sleep 0.5
done
