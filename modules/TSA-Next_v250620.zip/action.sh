#!/bin/sh

sleep 1s

pm list packages -3 | sed 's/package://g' > /data/adb/tricky_store/target.txt
  sed -i '/me.bmax.apatch/d' /data/adb/tricky_store/target.txt
  sed -i '/com.android.patch/d' /data/adb/tricky_store/target.txt
  sed -i '$ a\com.google.android.gms' /data/adb/tricky_store/target.txt
  sed -i '$ a\com.android.vending' /data/adb/tricky_store/target.txt
echo -e "执行结束"
echo -e ""
sleep 1s

echo -e "检测结果"
echo -e ""
sleep 1s
awk 'NR>=2{exit 0} END{exit NR<2}' /data/adb/tricky_store/target.txt && \
  echo "成功" || echo "失败，请检查是否为APatch管理器安装了1.5.5版本Cherish-Peekabo内核模块，此模块会拦截Pm命令返回结果。"
sleep 1s