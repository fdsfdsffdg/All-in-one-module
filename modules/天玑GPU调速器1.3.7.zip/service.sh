MODDIR=${0%/*}
mount -t debugfs none /sys/kernel/debug

sleep 60
nohup $MODDIR/gpu-scheduler > /dev/null 2>&1 &
